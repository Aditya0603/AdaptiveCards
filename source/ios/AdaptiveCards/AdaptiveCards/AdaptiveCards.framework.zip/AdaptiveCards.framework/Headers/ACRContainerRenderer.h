//
//  ACRContainerRenderer
//  ACRContainerRenderer.h
//
//  Copyright © 2017 Microsoft. All rights reserved.
//

#import "ACRBaseCardElementRenderer.h"

@interface ACRContainerRenderer: ACRBaseCardElementRenderer

+ (ACRContainerRenderer* ) getInstance;

@end
