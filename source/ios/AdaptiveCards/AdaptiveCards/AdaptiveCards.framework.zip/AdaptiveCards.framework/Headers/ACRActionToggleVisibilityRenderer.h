//
//  ACRActionToggleVisibilityRenderer
//  ACRActionToggleVisibilityRenderer.h
//
//  Copyright © 2018 Microsoft. All rights reserved.
//

#import "ACRBaseActionElementRenderer.h"

@interface ACRActionToggleVisibilityRenderer:ACRBaseActionElementRenderer

+ (ACRActionToggleVisibilityRenderer *)getInstance;

@end
