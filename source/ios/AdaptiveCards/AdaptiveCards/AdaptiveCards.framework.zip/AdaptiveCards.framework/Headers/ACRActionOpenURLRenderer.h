//
//  ACRActionOpenURLRenderer
//  ACRActionOpenURLRenderer.h
//
//  Copyright © 2017 Microsoft. All rights reserved.
//

#import "ACRBaseActionElementRenderer.h"

@interface ACRActionOpenURLRenderer:ACRBaseActionElementRenderer

+ (ACRActionOpenURLRenderer *)getInstance;

@end
